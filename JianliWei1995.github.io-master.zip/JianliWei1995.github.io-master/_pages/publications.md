---
layout: archive
permalink: /publications/
author_profile: true

---
You can also find my articles on <a href="https://scholar.google.com/citations?user=_Oq_-Z4AAAAJ&hl=en">my Google Scholar profile</a>.

{% include papers.md %}


<!---
#{% include base_path %}
#{% for post in site.pages %}
#{% include archive-single.html %}
#{% endfor %}
-->
